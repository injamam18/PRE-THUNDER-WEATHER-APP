# Prethunder-weather-app
A simple weather app 
Prethunder is a simple weather app displaying the temperature, minimum temperature, maximum temperature, weather at any time of any city. It also shows the wind speed,
pressure, humidity of any day.

Features-
1. Simple UI
2. Real time updation of weather(automatically updates every 10mins)
3. Consumes less space
4. Contains all the necessary details to know about the weather

Future improvements to be made-
1. Adding an option to add location by the user to know weather of any place
2. An option to automatically sset the weather by getting user's location
3. Option to notify user in case of bad weather
4. Better UI by changing the background image of the app with the changing weather


